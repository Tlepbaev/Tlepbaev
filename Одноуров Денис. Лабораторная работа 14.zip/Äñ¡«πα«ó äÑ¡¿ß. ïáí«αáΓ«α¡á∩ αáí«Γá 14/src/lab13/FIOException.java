package lab13;

public class FIOException extends Exception {
	public String toString() {
		return "IncorrectNameException";
	}
	private static final long serialVersionUID = 1L;

}
