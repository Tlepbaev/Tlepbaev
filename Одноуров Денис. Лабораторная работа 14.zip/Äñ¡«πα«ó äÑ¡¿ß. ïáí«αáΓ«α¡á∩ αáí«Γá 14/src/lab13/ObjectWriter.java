package lab13;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class ObjectWriter implements Serializable{
	private String filePath;
	public ObjectWriter(String filePath) {
		this.filePath=filePath;
	}
	public void writeObject(Object obj) {
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(this.filePath))){
			oos.writeObject(obj);
			System.out.println("������ ������� � ��������� ���� ��������� �������");
			oos.close();
		} 
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	public Object readObject() {
		Object obj = null;
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(this.filePath))){
			obj = ois.readObject();
		} 
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
		return obj;
	}
}
