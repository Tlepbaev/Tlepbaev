package lab13;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
public class MakeReport {
	String filePath;
	public MakeReport(String filePath) {
		this.filePath=filePath;
	}
	
	public void CreateReport(String line) throws FileNotFoundException, IOException {
		File file = new File(this.filePath);
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		PrintWriter pw = new PrintWriter(file);
		pw.print(line);
		pw.close();
	}
	
	public String[] ReadReport() throws FileNotFoundException, IOException {
		String[] str = new String[this.size()];
		BufferedReader bw = new BufferedReader(new FileReader(this.filePath));
		for(int i = 0; i < this.size(); i++) {
			str[i]=bw.readLine();
		}
		return str;
	}
	
	public int size() {
		int i = 0;
		String str = new String();
		try {
			BufferedReader bw = new BufferedReader(new FileReader(this.filePath));
			while((str = bw.readLine()) != null) {
				i++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return i;
	}
}
