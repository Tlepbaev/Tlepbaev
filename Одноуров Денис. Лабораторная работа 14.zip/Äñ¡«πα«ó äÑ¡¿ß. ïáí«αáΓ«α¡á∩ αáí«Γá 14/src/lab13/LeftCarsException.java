package lab13;

public class LeftCarsException extends Exception{
	public LeftCarsException(){
	}
	public String toString() {
		return "NotEnoughCarsException";
	}
	private static final long serialVersionUID = 1L;

}
