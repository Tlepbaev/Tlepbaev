package ������5;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Report {
	
	public static void CreateReport(String filePath, String line) throws FileNotFoundException, IOException {
		File file = new File(filePath);
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		PrintWriter pw = new PrintWriter(file);
		pw.print(line);
		pw.close();
	}
	
	public static String[] ReadReport(String filePath) throws FileNotFoundException, IOException {
		String[] str = new String[size(filePath)];
		BufferedReader bw = new BufferedReader(new FileReader(filePath));
		for(int i = 0; i < size(filePath); i++) {
			str[i]=bw.readLine();
		}
		return str;
	}
	
	public static int size(String filePath) {
		int i = 0;
		String str = new String();
		try {
			BufferedReader bw = new BufferedReader(new FileReader(filePath));
			while((str = bw.readLine()) != null) {
				i++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return i;
	}
}
