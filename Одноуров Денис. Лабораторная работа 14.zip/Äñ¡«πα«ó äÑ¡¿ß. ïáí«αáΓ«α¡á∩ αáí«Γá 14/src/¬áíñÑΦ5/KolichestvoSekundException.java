package ������5;

public class KolichestvoSekundException extends Exception {
	private String declare;
	
	public KolichestvoSekundException(int time) {
		this.declare = ". Unavalible time entered: " + time;
	}
	
	public String toString() {
		return "KolichestvoSekundException" + declare;
	}
	
	private static final long serialVersionUID = 1L;

}
