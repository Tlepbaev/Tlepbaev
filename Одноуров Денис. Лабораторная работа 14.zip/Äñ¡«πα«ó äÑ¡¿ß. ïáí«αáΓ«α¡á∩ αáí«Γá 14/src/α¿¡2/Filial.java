package ���2;
import java.io.Serializable;
import java.util.ArrayList;

public class Filial implements Serializable{

	private String name;
	private int totalAmount;
	private Bank bank;
	private ArrayList<Contribution> contributions = new ArrayList<Contribution>();
	//������ ��� ������� � ����, � �������� ����������� ������ � ������������
	public Filial(String name, Bank bank) {
		this.name=name;
		this.bank=bank;
		bank.addFilial(this);
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTotalAmount() {
		this.totalAmount=0;
		for(int i = 0; i < this.contributions.size();i++) {
			this.totalAmount+=this.contributions.get(i).getSum();
		}
		return totalAmount;
	}

	public void setBank(Bank bank) {
		this.bank=bank;
		bank.addFilial2(this);
	}
	
	public void setBank2(Bank bank) {
		this.bank=bank;
	}

	public Bank getBanks() {
		return bank;
	}
	
	public void removeBank() {
		this.bank=null;
		bank.removeFilial2(this);
	}
	
	public void removeBank2() {
		this.bank=null;
	}

	public ArrayList<Contribution> getContributions(){
		return contributions;
	}
	
	public Contribution getContribution(int i){
		return contributions.get(i);
	}
	
	public void addContributor(Contribution contribution) {
		this.contributions.add(contribution);
		contribution.setFilial2(this);
	}
	
	public void addContributor2(Contribution contribution) {
		this.contributions.add(contribution);
	}
	
	public void removeContributor(Contribution contribution) {
		this.contributions.remove(contribution);
		contribution.removeFilia2();
	}
	
	public void removeContributor2(Contribution contribution) {
		this.contributions.remove(contribution);
	}
}
