package ���2;

public class KolichestvoException extends Exception {

	public String toString() {
		return "KolichestvoException";
	}
	private static final long serialVersionUID = 1L;

}
