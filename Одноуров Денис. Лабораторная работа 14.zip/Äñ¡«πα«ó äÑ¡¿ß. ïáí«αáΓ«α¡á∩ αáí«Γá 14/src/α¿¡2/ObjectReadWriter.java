package ���2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectReadWriter {
	public void writeObject(Object obj, String filePath) {
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))){
			oos.writeObject(obj);
			oos.close();
		} 
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	public Object readObject(String filePath) {
		Object obj = null;
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))){
			obj = ois.readObject();
		} 
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
		return obj;
	}
}
