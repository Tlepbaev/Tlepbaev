package ���2;

public class VkladException extends Exception {

	private static final long serialVersionUID = 1L;

}
