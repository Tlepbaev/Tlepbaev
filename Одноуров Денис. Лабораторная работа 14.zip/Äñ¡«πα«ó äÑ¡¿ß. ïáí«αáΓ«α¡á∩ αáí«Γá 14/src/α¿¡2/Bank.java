package ���2;
import java.io.Serializable;
import java.util.ArrayList;

public class Bank  implements Serializable{
	private String name;
	private ArrayList<Filial> filials = new ArrayList<Filial>();
	//������ ��� ����� � ������������
	public Bank(String name) {
		this.name=name;
		
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public ArrayList<Filial> getFilials(){
		return filials;
	}
	
	public Filial getFilial(Filial filial){
		return (Filial)filials.get(filials.indexOf(filial));
	}
	
	public void addFilial(Filial filial) {
		filials.add(filial);
		filial.setBank2(this);
	}
	
	public void addFilial2(Filial filial) {
		filials.add(filial);
	}

	public void removeFilial(Filial filial) {
		filials.remove(filial);
		filial.removeBank();
	}
	
	public void removeFilial2(Filial filial) {
		filials.remove(filial);
	}
	
}
