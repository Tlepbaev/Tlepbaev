package �����1;

import java.util.Scanner;
public class Reader {
	public static String readLine() {
		String s = new String();
		Scanner scanner = new Scanner(System.in);
		if(scanner.hasNextLine()) {
			s = scanner.nextLine();
		}
		return s;
	}
	
	public static int readInt() throws NumberFormatException{
		int n = 0;
		Scanner scanner = new Scanner(System.in);
		if(scanner.hasNextInt()) {
			n = scanner.nextInt();
		}
		return n;
	}
}
