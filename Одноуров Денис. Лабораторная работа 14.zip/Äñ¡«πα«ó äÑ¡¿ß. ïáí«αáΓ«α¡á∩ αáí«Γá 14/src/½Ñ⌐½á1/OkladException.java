package �����1;

public class OkladException extends Exception {

	public String toString() {
		return "OkladException";
	}
	private static final long serialVersionUID = 1L;

}
