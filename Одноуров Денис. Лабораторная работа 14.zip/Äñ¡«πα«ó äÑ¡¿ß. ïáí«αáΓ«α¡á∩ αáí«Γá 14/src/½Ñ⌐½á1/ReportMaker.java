package �����1;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
public class ReportMaker {
	public ReportMaker() {
	}
	
	public void MakeReport(Firm firm, String filePath) throws FileNotFoundException, IOException {
		File file = new File(filePath);
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		String reportText = new String("�������� �����: " + firm.getName());
		
		for(int i = 0; i < firm.getOtdels().size(); i++) {
			Otdel otd = firm.getOtdels().get(i);
			reportText += "\n�����: " + otd.getName() + "\n";
			for(int j = 0; j < otd.getStaffs().size(); j++) {
				Staff staff = otd.getStaffs().get(j);
				reportText +="���: " + staff.getFIO();
				reportText +="���������: " + staff.getDoljnost();
				reportText +="�����: " + staff.getOklad();
				if(staff instanceof ShtatStaff) {
					reportText +="������: " + ((ShtatStaff) staff).getPrem() + "\n";
				}
				else reportText += "\n";
				reportText += "���������� ����������� � ������: " + otd.getStaffs().size() + "\n\n";
			}		
		}
		PrintWriter pw = new PrintWriter(file);
		pw.print(reportText);
		pw.close();
	}
	
	public void ReadReport(String filePath) throws FileNotFoundException, IOException {
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line;
		while((line = br.readLine())!=null) {
			System.out.println(line);
		}
		br.close();
	}
}
