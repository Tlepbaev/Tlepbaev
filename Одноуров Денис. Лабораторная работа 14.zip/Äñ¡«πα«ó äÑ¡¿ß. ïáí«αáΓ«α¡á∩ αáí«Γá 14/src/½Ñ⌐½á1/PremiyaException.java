package �����1;

public class PremiyaException extends Exception {

	public String toString() {
		return "PremiyaException";
	}
	private static final long serialVersionUID = 1L;

}
