package �������7;

public class ProdolzhitelnostException extends Exception {
	public String toString() {
		return "ProdolzhitelnostException";
	}
	private static final long serialVersionUID = 1L;

}