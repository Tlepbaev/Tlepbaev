package �������7;

public class NazvanieException extends Exception {
	public String toString() {
		return "NazvanieException";
	}
	private static final long serialVersionUID = 1L;
}
