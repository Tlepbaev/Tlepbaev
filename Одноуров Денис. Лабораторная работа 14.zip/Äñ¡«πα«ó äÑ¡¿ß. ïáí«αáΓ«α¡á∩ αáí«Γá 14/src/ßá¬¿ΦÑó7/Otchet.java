package �������7;

import java.io.*;;

public class Otchet {
	String filePath;
	public Otchet(String filePath) {
		this.filePath=filePath;
	}
	
	public void CreateReport(String line) throws FileNotFoundException, IOException {
		File file = new File(this.filePath);
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		PrintWriter pw = new PrintWriter(file);
		pw.print(line);
		pw.close();
	}
	
	public String[] ReadReport() throws FileNotFoundException, IOException {
		String[] str = new String[this.size()];
		BufferedReader bw = new BufferedReader(new FileReader(this.filePath));
		for(int i = 0; i < this.size(); i++) {
			str[i]=bw.readLine();
		}
		return str;
	}
	
	public int size() {
		int i = 0;
		String str = new String();
		try {
			BufferedReader bw = new BufferedReader(new FileReader(this.filePath));
			while((str = bw.readLine()) != null) {
				i++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return i;
	}
}
