package test;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import lab13.ObjectWriter;

@SuppressWarnings("serial")
public class TabbedPane extends JFrame {
	public TabbedPane() {
		this.setTitle("Tabbed Pane");
		JTabbedPane jtp = new JTabbedPane();
		setSize(300, 200);
		this.getContentPane().add(jtp);
		JPanel jp1 = new JPanel();
		JPanel jp2 = new JPanel();
		JLabel jl1 = new JLabel();
		jl1.setText("area of tab1");
		JLabel jl2 = new JLabel();
		jl2.setText("area of tab2");
		jp1.add(jl1);
		jp2.add(jl2);
		jtp.addTab("������", jp1);
		jtp.addTab("������", jp2);
	}
	public static void main(String[] args) {
		TabbedPane tp = new TabbedPane();
		tp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		tp.setVisible(true);
	}

	
}
